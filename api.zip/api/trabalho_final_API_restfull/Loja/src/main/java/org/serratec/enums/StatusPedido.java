package org.serratec.enums;

public enum StatusPedido {

	AGUARDANDO_PAGAMENTO,
	PAGO,
	ENVIADO,
	FINALIZADO;
	}

