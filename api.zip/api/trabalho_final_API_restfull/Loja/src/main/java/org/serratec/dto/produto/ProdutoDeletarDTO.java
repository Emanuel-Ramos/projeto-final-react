package org.serratec.dto.produto;

public class ProdutoDeletarDTO {

	private String codigo;

	public String getCodigo() {
		return codigo;
	}
	
	
	
}
