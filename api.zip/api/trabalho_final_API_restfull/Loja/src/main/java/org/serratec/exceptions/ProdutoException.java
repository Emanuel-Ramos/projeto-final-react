package org.serratec.exceptions;

public class ProdutoException extends Exception {

	private static final long serialVersionUID = 6357897168068494273L;	
	
	public ProdutoException(String message) {
		super(message);
	}

}
