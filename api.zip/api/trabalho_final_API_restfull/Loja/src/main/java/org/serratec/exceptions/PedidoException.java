package org.serratec.exceptions;

public class PedidoException extends Exception {

	private static final long serialVersionUID = 6258827125097848608L;

	public PedidoException(String message) {
		super(message);
	}
}
