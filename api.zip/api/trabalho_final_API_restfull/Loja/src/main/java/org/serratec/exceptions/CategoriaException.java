package org.serratec.exceptions;

public class CategoriaException extends Exception {

	private static final long serialVersionUID = -3477201227094722934L;

	public CategoriaException(String message) {
		super(message);
	}
}
