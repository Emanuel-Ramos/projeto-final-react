package org.serratec.exceptions;

public class ClienteException extends Exception {

	private static final long serialVersionUID = -3477201227094722934L;

	public ClienteException(String message) {
		super(message);
	}
}
