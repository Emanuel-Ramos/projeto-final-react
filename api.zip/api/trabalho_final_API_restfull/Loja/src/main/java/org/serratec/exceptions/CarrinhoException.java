package org.serratec.exceptions;

public class CarrinhoException extends Exception {

	private static final long serialVersionUID = 6357897168068494273L;	
	
	public CarrinhoException(String message) {
		super(message);
	}

}
