package org.serratec.dto.categoria;

public class CategoriaAtualizarDTO {

	private String nome;
	private String codigo;
	private String descricao;
	
	public String getNome() {
		return nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public String getCodigo() {
		return codigo;
	}
}
