package org.serratec.dto.categoria;

public class CategoriaDeletarDTO {

	private String nome;

	public String getNome() {
		return nome;
	}
	
}
